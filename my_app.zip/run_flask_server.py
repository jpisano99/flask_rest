from my_app import app as application

# Run the Flask development server from here
if __name__ == '__main__':
    application.run(debug=True)