# Passwords configuration settings

passwords = dict(
    # DB_PASSWORD = "YWUjLCCc2v7mTh3",
    DB_PASSWORD = "db_password",
    SS_TOKEN = "ss_token",
    USER_PASSWORD = "stan"
)
