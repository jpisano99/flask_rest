def main():
    print('Hello from main.py')
    return

