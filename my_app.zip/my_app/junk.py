from my_app import db
from my_app.models import Test_Table
from my_app.func_lib.db_tools import table_exist, create_tables, drop_tables
import os
print(os.environ)
print(os.getenv('ALLUSERSPROFIE'))
exit()

tbl_name = "Test_Table"
stan = drop_tables(tbl_name)
# stan = create_tables(tbl_name)

print('does it', stan)
exit()


print(db.engine.table_names())
exit()

jim = "Test_Table.__table__.create(db.session.bind)"

exec(jim)
exit()
db.create_all()

print('Database initialized')
exit()


import os
print(os.environ)
exit()




#from my_app.settings import db_config


db_config = dict(
    DATABASE="jpisano$ta_adoption_db",
    USER="jpisano",
    PASSWORD="Wdst12498",
    HOST="jpisano.mysql.pythonanywhere-services.com"
)


SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://{username}:{password}@{hostname}/{databasename}".format(
    username="jpisano",
    password="Wdst12498",
    hostname="jpisano.mysql.pythonanywhere-services.com",
    databasename="jpisano$ta_adoption_db",
)
print(SQLALCHEMY_DATABASE_URI)


jim = 'mysql+mysqlconnector://' +\
        db_config['USER'] +\
        ':'+db_config['PASSWORD'] +\
        '@'+db_config['HOST']+'/' +\
        db_config['DATABASE']

print(jim)